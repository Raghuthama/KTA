declare @org_name nvarchar(100) = 'Kofax'
declare @BU_count int = 6
declare @create_VisOperBU int = 1

declare @Vendor_Group_count int = 2
declare @Vendor_Naming_count int = 3 --Do not change
declare @Vendor_count int = 2
declare @Exception_Handler nvarchar(50) = N''
declare @Invoice_Coder nvarchar(50) = N''
declare @Segment_Names_count int = 15

DECLARE @RC int
DECLARE @ORGANIZATION_ID int
DECLARE @ORGANIZATION_NAME nvarchar(100) = @org_name
DECLARE @DESCRIPTION nvarchar(max) = N'This company "' + @org_name + N'"have been created by script at ' +  convert(varchar(25), SYSDATETIME(), 120)
DECLARE @ERP_CONNECTION_ID int = (select max(ERP_CONNECTION_ID) from [dbo].[ERP_CONNECTIONS])
DECLARE @ERP_ORGANIZATION_ID nvarchar(100) = @org_name
DECLARE @ERP_ORGANIZATION_NAME nvarchar(100) = @org_name
DECLARE @GL_STRUCTURE_ID int = (select max(GL_STRUCTURE_ID) from [dbo].[SEGMENT_STRUCTURE])
DECLARE @IPA_CLIENT_ID int = (select isNull(max(IPA_CLIENT_ID),-1)+1 from ORGANIZATIONS)
DECLARE @ACTIVE bit = 1

if @ERP_CONNECTION_ID is null begin
        insert into ERP_CONNECTIONS(CONNECTION_NAME, DESCRIPTION, ERP_CONNECTION_TYPE_ID, LAST_CHANGED_TS)
                   values(N'Agnostic', N'Agnostic Description', 1, SYSDATETIME());
        select @ERP_CONNECTION_ID = max(ERP_CONNECTION_ID) from [dbo].[ERP_CONNECTIONS];
end;

if @GL_STRUCTURE_ID is null begin
	insert into SEGMENT_STRUCTURE(STRUCTURE_NAME, DESCRIPTION, SEGMENT_SEPARATOR, LAST_CHANGED_TS)
		   values (N'Struc1', N'GL Structure created by script', N'-', SYSDATETIME());
	select @GL_STRUCTURE_ID = max(GL_STRUCTURE_ID) from [dbo].[SEGMENT_STRUCTURE];

	declare @cnt int = 0;
	while @cnt < @Segment_Names_count begin
		set @cnt = @cnt + 1;
		insert into SEGMENT_NAMES(GL_STRUCTURE_ID, SEGMENT_NUMBER, VISIBLE_NAME, ORDER_NUMBER, LAST_CHANGED_TS)
			   values (@GL_STRUCTURE_ID, N'Segment'+cast(@cnt as nvarchar), N'Segment'+cast(@cnt as nvarchar), @cnt, SYSDATETIME());
	end;
end;

-- TODO: Set parameter values here.
EXECUTE @RC = [dbo].[Create_Organization] 
   @ORGANIZATION_ID OUTPUT
  ,@ORGANIZATION_NAME
  ,@DESCRIPTION
  ,@ERP_CONNECTION_ID
  ,@ERP_ORGANIZATION_ID
  ,@ERP_ORGANIZATION_NAME
  ,@GL_STRUCTURE_ID
  ,@IPA_CLIENT_ID
  ,@ACTIVE
