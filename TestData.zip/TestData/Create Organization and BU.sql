-- *** Update these variables if need to change organization settings *** ---
declare @l_orgBaseType int = 0;
declare @l_orgBaseID int = 1;
declare @l_org_Name nvarchar(100) = 'Kofax (Test)';
declare	@l_captureProfileTemplateId nvarchar(100) = '-2';
declare	@l_exportProfileTemplateId nvarchar(100) = '-2';
declare	@l_instructionsProfileId nvarchar(100) = '0';
declare	@l_forceVerify bit = 0;
declare	@l_bypassValidation bit = 0;
declare	@l_orgGroupId nvarchar(100) = '1'
declare	@l_vendorPartitionId nvarchar(100) = '0'
declare	@l_employeePartitionId nvarchar(100) = '0'
declare	@l_poPartitionId nvarchar(100) = '-1'
declare	@l_taxPartitionId nvarchar(100) = '-1'
declare @l_Description nvarchar(max) = N'Generic + Agnostic + AP Workflow';
declare	@l_UseErpConnector BIT = 1;
declare @l_ERPOrgID nvarchar(100) = '1';
declare @l_ERPOrgName nvarchar(100) = 'Kofax (Test)';
declare	@l_UseAPworkflow BIT = 1;
declare @l_Active bit = 1;
declare @l_Segment_Count int = 1;
-- *** Update variables above if need to change organization settings *** ---

-- *** Update these variables if need to change business unit settings *** ---
declare @l_BUSINESS_UNIT_NAME [nvarchar](100) = N'Perceptive Software LLC';
declare @l_BU_DESCRIPTION [nvarchar](max) = N'Test';
declare @l_ERP_BUSINESS_UNIT_ID [nvarchar](100) = N'2000';
declare @l_ERP_BUSINESS_UNIT_NAME [nvarchar](100) = N'Perceptive Software LLC';
declare @l_BUSINESS_UNIT_ADDRESS [nvarchar](250) = N'Unit 20, Business Centre Technology Drive Beeston, Nottingham, NG15 7UT';
declare @l_BU_ACTIVE [bit] = 1;
declare @l_ROUTING_ORDER_ID [nvarchar](100) = N'5';
declare @l_COUNTRY [nvarchar](60)= N'USA';
declare @l_CURRENCY_CODE [nvarchar](3) = N'USD';
declare @l_AUTOAPPROVAL_THRESHOLD [decimal](18, 2) = 0;
declare @l_EMAIL_APPROVAL [bit] = 0;
declare @l_USE_APPROVAL_CHAIN [bit] = 0;
declare @l_MAX_GR_WAIT_PERIOD [int] = 0;
declare @l_REPLY_EMAIL_ADDRESS [nvarchar](100) = N'test@mailaddress.com';
-- *** Update variables above if need to change business unit settings *** ---

declare @l_ERPConnectionID nvarchar(100) = (select max(ERP_CONNECTION_ID) from [dbo].[ERP_CONNECTIONS] where CONNECTION_NAME = N'Agnostic');
declare @l_GL_StructureId nvarchar(100) = (select max(GL_STRUCTURE_ID) from [dbo].[SEGMENT_STRUCTURE]);

declare	@l_ErrorInfo nvarchar(max); 
declare	@l_NewOrgID numeric(18,0);
declare	@l_NewAP_OrgID numeric(18,0);
declare	@l_NewOrgName as varchar(50);
declare	@l_errorCode int;
declare @l_NewBusUnitID [int];
declare @l_NewBusUnitName [nvarchar](100);
declare @l_AddSuccess bit;


if @l_ERPConnectionID is null begin
   insert into ERP_CONNECTIONS(CONNECTION_NAME, DESCRIPTION, ERP_CONNECTION_TYPE_ID, LAST_CHANGED_TS, USE_DEFAULT_NULL_VALUES_FOR_DATA_IMPORT)
          values(N'Agnostic', N'Agnostic Description', 1, SYSDATETIME(), 1);
    select @l_ERPConnectionID = max(ERP_CONNECTION_ID) from [dbo].[ERP_CONNECTIONS];
end;

if @l_GL_StructureId is null begin
	insert into SEGMENT_STRUCTURE(STRUCTURE_NAME, DESCRIPTION, SEGMENT_SEPARATOR, LAST_CHANGED_TS)
		   values (N'Struc1', N'GL Structure created by script', N'-', SYSDATETIME());
	select @l_GL_StructureId = max(GL_STRUCTURE_ID) from [dbo].[SEGMENT_STRUCTURE];

	declare @cnt int = 0;
	while @cnt < @l_Segment_Count begin
		set @cnt = @cnt + 1;
		insert into SEGMENT_NAMES(GL_STRUCTURE_ID, SEGMENT_NUMBER, VISIBLE_NAME, ORDER_NUMBER, LAST_CHANGED_TS)
			   values (@l_GL_StructureId, N'Segment'+cast(@cnt as nvarchar), N'Segment'+cast(@cnt as nvarchar), @cnt, SYSDATETIME());
	end;
end;

exec SP_createUnifiedOrganization 
	@orgBaseType=@l_orgBaseType,
	@orgBaseID=@l_orgBaseID,
	@org_name=@l_org_name,
	@captureProfileTemplateId=@l_captureProfileTemplateId,
	@exportProfileTemplateId=@l_exportProfileTemplateId,
	@instructionsProfileId=@l_instructionsProfileId,
	@forceVerify=@l_forceVerify,
	@bypassValidation=@l_bypassValidation,
	@orgGroupId=@l_orgGroupId,
	@vendorPartitionId=@l_vendorPartitionId,
	@employeePartitionId=@l_employeePartitionId,
	@poPartitionId=@l_poPartitionId,
	@taxPartitionId=@l_taxPartitionId,
	@Description=@l_Description,
	@UseErpConnector=@l_UseErpConnector,
	@ERPConnectionID=@l_ERPConnectionID,
	@ERPOrgID=@l_ERPOrgID,
	@ERPOrgName=@l_ERPOrgName,
	@UseAPworkflow=@l_UseAPworkflow,
	@GL_StructureId=@l_GL_StructureId,
	@Active=@l_Active,
	@ErrorInfo=@l_ErrorInfo output,
	@NewOrgID=@l_NewOrgID output,
	@NewAP_OrgID=@l_NewAP_OrgID output,
	@NewOrgName=@l_NewOrgName output,
	@errorCode=@l_errorCode output

if @l_NewOrgID is not null begin
	exec SP_CreateBusinessUnits 
		@BUSINESS_UNIT_NAME=@l_BUSINESS_UNIT_NAME,
		@ExistingOrgID=@l_NewOrgID,
		@DESCRIPTION=@l_BU_DESCRIPTION,
		@ERP_BUSINESS_UNIT_ID=@l_ERP_BUSINESS_UNIT_ID,
		@ERP_BUSINESS_UNIT_NAME=@l_ERP_BUSINESS_UNIT_NAME,
		@BUSINESS_UNIT_ADDRESS=@l_BUSINESS_UNIT_ADDRESS,
		@ACTIVE=@l_BU_ACTIVE,
		@ROUTING_ORDER_ID=@l_ROUTING_ORDER_ID,
		@COUNTRY=@l_COUNTRY,
		@CURRENCY_CODE=@l_CURRENCY_CODE,
		@AUTOAPPROVAL_THRESHOLD=@l_AUTOAPPROVAL_THRESHOLD,
		@EMAIL_APPROVAL=@l_EMAIL_APPROVAL,
		@USE_APPROVAL_CHAIN=@l_USE_APPROVAL_CHAIN,
		@MAX_GR_WAIT_PERIOD=@l_MAX_GR_WAIT_PERIOD,
		@REPLY_EMAIL_ADDRESS=@l_REPLY_EMAIL_ADDRESS,
		@ErrorInfo=@l_ErrorInfo output,
		@NewBusUnitID=@l_NewBusUnitID output,
		@NewBusUnitName=@l_NewBusUnitName output,
		@AddSuccess=@l_AddSuccess output
	
	if @l_NewBusUnitID is not null begin
	
		exec Create_DefRoles_By_BU @BU_ID = @l_NewBusUnitId
		
			
		update BU_ROLES set RESOURCE_ID = N'959EDE558F3D43389F0146F2368BF256'
			where ROLE_ID = 1 and BUSINESS_UNIT_ID = @l_NewBusUnitId

		update BU_ROLES set RESOURCE_ID = N'B4751976BA314AE9AC81DE2B9052EF90'
			where ROLE_ID = 2 and BUSINESS_UNIT_ID = @l_NewBusUnitId

	    update BU_ROLES set RESOURCE_ID = N'9A1EB2D6DB2645C2A667CC4AF91B3955'
			where ROLE_ID = 3 and BUSINESS_UNIT_ID = @l_NewBusUnitId

		update BU_ROLES set RESOURCE_ID = N'7AFD7C2C316548CF80D6C606BEE3F582'
			where ROLE_ID = 4 and BUSINESS_UNIT_ID = @l_NewBusUnitId

		update BU_ROLES set RESOURCE_ID = N'203D1E72492B495CA8DC8574DA406BDF'
			where ROLE_ID = 5 and BUSINESS_UNIT_ID = @l_NewBusUnitId

		update BU_ROLES set RESOURCE_ID = N'7DF43CCDF24611D2804B00104B71BD15'
			where ROLE_ID = 6 and BUSINESS_UNIT_ID = @l_NewBusUnitId
	end 
end;

select @l_ErrorInfo;